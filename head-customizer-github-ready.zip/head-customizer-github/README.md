# Head Customizer

Static browser-based mascot head customizer.

## GitHub Pages

This repository is ready for GitHub Pages. Serve the repository root from the `main` branch.

## Files

- `index.html` — app
- `.nojekyll` — prevents Jekyll processing
